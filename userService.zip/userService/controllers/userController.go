
package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
)

func RegisterUser(c *gin.Context) {
    c.JSON(http.StatusOK, gin.H{"message": "User registered"})
}

func LoginUser(c *gin.Context) {
    c.JSON(http.StatusOK, gin.H{"message": "User logged in"})
}

func GetUserByID(c *gin.Context) {
    userID := c.Param("id")
    c.JSON(http.StatusOK, gin.H{"user_id": userID})
}
